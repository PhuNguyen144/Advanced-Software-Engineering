public interface SortStrategy {
    void sort(int[] array);
}
